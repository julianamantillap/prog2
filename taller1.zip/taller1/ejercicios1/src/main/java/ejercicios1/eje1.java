/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios1;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class eje1 {
    public static void main(String[] args) {
    Scanner teclado = new Scanner (System.in);
    
    String nombre;
    
    System.out.println("dime tu nombre porfavor");
    nombre = teclado.nextLine();
    
    System.out.println("hola " + nombre + " , bienvenida");
    
    
    
    
}

}